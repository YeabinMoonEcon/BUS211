df <- anscombe
plot(x1,y1)
